<?php
defined( 'ABSPATH' ) || die();

require_once WLSM_PLUGIN_DIR_PATH . 'public/inc/account/parent/partials/back.php';
require_once WLSM_PLUGIN_DIR_PATH . 'public/inc/account/settings.php';
